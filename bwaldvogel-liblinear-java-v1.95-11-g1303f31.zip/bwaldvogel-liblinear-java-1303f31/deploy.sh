#!/bin/bash
gradle clean build uploadArchives
